var json_Texas_Major_Cities_2 = {
"type": "FeatureCollection",
"name": "Texas_Major_Cities_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OBJECTID": "623", "GID": "1165", "CITY_NM": "Austin", "CITY_NBR": "2100", "INC_FLAG": "Yes", "CNTY_SEAT": "Yes", "CITY_FIPS": "4805000", "POP1990": "465622", "POP2000": "656562", "POP2010": "790390", "CNTY_NBR": "227", "DIST_NBR": "14" }, "geometry": { "type": "Point", "coordinates": [ -97.74447762078222, 30.273565216483959 ] } },
{ "type": "Feature", "properties": { "OBJECTID": "1402", "GID": "1074", "CITY_NM": "Dallas", "CITY_NBR": "10850", "INC_FLAG": "Yes", "CNTY_SEAT": "Yes", "CITY_FIPS": "4819000", "POP1990": "1006877", "POP2000": "1188580", "POP2010": "1197816", "CNTY_NBR": "57", "DIST_NBR": "18" }, "geometry": { "type": "Point", "coordinates": [ -96.807957527516564, 32.779585734957614 ] } },
{ "type": "Feature", "properties": { "OBJECTID": "2984", "GID": "2659", "CITY_NM": "Houston", "CITY_NBR": "19750", "INC_FLAG": "Yes", "CNTY_SEAT": "Yes", "CITY_FIPS": "4835000", "POP1990": "1630553", "POP2000": "1953631", "POP2010": "2099451", "CNTY_NBR": "102", "DIST_NBR": "12" }, "geometry": { "type": "Point", "coordinates": [ -95.359716997927848, 29.760395199373054 ] } },
{ "type": "Feature", "properties": { "OBJECTID": "3028", "GID": "2703", "CITY_NM": "San Antonio", "CITY_NBR": "37450", "INC_FLAG": "Yes", "CNTY_SEAT": "Yes", "CITY_FIPS": "4865000", "POP1990": "935933", "POP2000": "1144646", "POP2010": "1327407", "CNTY_NBR": "15", "DIST_NBR": "15" }, "geometry": { "type": "Point", "coordinates": [ -98.494987772280751, 29.422725019176976 ] } }
]
}
